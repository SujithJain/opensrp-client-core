package org.smartregister.cursoradapter;

import org.smartregister.view.dialog.FilterOption;

public interface CursorFilterOption extends FilterOption {
    String filter();
}
