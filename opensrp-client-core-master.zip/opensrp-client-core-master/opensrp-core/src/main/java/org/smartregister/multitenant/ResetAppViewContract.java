package org.smartregister.multitenant;

/**
 * Created by Ephraim Kigamba - nek.eam@gmail.com on 09-04-2020.
 */
public interface ResetAppViewContract {

    interface View {


    }

    interface Model {

    }

    interface Presenter {

    }


}
