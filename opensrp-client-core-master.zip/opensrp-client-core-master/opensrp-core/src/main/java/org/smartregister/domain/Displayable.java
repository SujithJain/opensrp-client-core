package org.smartregister.domain;

public interface Displayable {
    String displayValue();
}
