package org.smartregister.domain.db;

public interface Column {

    ColumnAttribute column();

    String name();
}
