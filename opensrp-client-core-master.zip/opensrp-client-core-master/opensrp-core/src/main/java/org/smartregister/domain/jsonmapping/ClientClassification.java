package org.smartregister.domain.jsonmapping;

import java.util.List;

/**
 * Created by keyman on 2/21/2018.
 */

public class ClientClassification {
    public List<ClassificationRule> case_classification_rules;
}
