package org.smartregister.domain.jsonmapping;

public interface ColumnType {
    String Date = "date";
    String String = "string";
}
