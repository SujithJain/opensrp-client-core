package org.smartregister.domain.jsonmapping;

import java.util.List;

/**
 * Created by keyman on 2/21/2018.
 */

public class Field {
    public String field;
    public String concept;
    public String field_value;
    public List<String>values;
    public List<String> creates_case;
    public List<String> closes_case;
}
