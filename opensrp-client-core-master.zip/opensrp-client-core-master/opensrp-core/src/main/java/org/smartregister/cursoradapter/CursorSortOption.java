package org.smartregister.cursoradapter;

import org.smartregister.view.dialog.SortOption;

public interface CursorSortOption extends SortOption {
    String sort();
}
