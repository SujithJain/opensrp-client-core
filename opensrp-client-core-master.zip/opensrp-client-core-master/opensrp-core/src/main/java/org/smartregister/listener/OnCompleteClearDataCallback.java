package org.smartregister.listener;

/**
 * Created by Ephraim Kigamba - nek.eam@gmail.com on 29-04-2020.
 */
public interface OnCompleteClearDataCallback {

    void onComplete();
}
