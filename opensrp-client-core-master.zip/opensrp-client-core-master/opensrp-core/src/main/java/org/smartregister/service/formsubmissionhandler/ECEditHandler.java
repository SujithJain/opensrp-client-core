package org.smartregister.service.formsubmissionhandler;

import org.smartregister.domain.form.FormSubmission;

public class ECEditHandler implements FormSubmissionHandler {

    @Override
    public void handle(FormSubmission submission) {
    }
}
