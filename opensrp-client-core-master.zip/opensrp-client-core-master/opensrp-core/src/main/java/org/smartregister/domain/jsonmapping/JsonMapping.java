package org.smartregister.domain.jsonmapping;

/**
 * Created by keyman on 2/21/2018.
 */

public class JsonMapping {
    public String field;
    public String concept;
    public String formSubmissionField;
    public String value_field;
    public String event_type;
}

