package org.smartregister.commonregistry;

import org.smartregister.view.contract.SmartRegisterClients;

/**
 * Created by Raihan Ahmed on 2/12/15.
 */
public class CommonPersonObjectClients extends SmartRegisterClients {
}
