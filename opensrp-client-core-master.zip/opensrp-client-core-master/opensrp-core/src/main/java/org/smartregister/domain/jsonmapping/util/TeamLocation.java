package org.smartregister.domain.jsonmapping.util;

public class TeamLocation {

    public String uuid;

    public String name;

    public String display;
}
