package org.smartregister.domain.jsonmapping;

/**
 * Created by keyman on 2/21/2018.
 */

public class ClassificationRule {
    public String comment;
    public Rule rule;
}
