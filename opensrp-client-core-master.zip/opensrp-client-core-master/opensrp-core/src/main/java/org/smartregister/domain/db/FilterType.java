package org.smartregister.domain.db;

public enum FilterType {
    AND, OR
}

	