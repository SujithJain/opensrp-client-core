package org.smartregister.domain.jsonmapping;

import java.util.List;

/**
 * Created by keyman on 2/21/2018.
 */

public class Table {
    public String name;
    public List<Column> columns;
}
