package org.smartregister.commonregistry;

/**
 * Created by raihan on 2/8/16.
 */
public abstract class ControllerFilterMap {

    public abstract boolean filtermapLogic(CommonPersonObject commonPersonObject);
}