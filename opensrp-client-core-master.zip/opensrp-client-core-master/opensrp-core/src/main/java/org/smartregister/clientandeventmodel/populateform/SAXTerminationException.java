package org.smartregister.clientandeventmodel.populateform;


import org.xml.sax.SAXException;

/**
 * Created by samuelgithengi on 1/23/18.
 */

public class SAXTerminationException extends SAXException {
    public SAXTerminationException(String s) {
        super(s);
    }
}
