package org.smartregister.domain.jsonmapping;

import java.util.List;

/**
 * Created by keyman on 2/21/2018.
 */

public class ClientField {
    public List<Table> bindobjects;
}
