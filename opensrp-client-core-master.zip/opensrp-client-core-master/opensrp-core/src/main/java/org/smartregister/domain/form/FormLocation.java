package org.smartregister.domain.form;

import java.util.List;

/**
 * Created by keyman on 3/1/2018.
 */

public class FormLocation {
    public String name;
    public String key;
    public String level;
    public List<FormLocation> nodes;
}
