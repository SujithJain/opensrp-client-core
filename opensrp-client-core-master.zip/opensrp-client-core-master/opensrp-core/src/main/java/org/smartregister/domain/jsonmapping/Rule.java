package org.smartregister.domain.jsonmapping;

import java.util.List;

/**
 * Created by keyman on 2/21/2018.
 */

public class Rule {
    public String type;
    public List<Field> fields;
}
